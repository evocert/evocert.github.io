define(["module"],function(module){
	module.exports="foo";
});
